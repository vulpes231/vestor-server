const allowedOrigins = [
  "https://vestorr.netlify.app",
  "http://localhost:5173",
  "https://vestor.markets",
];

module.exports = { allowedOrigins };
