const { MongoClient } = require("mongodb");
require("dotenv").config();

// MongoDB connection URL
const url = process.env.DATABASE_URI;
const dbName = "test";

async function checkIndexes() {
  const client = new MongoClient(url, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  try {
    await client.connect();
    console.log("Connected to MongoDB");

    const db = client.db(dbName);
    const usersCollection = db.collection("users");

    // Get all indexes on the users collection
    const indexes = await usersCollection.indexes();
    console.log('Indexes on "users" collection:', indexes);

    // If there's an index on "fullname", drop it
    const fullnameIndex = indexes.find((index) => index.name === "pin_1");
    if (fullnameIndex) {
      console.log("Found index on pin, dropping it...");
      await usersCollection.dropIndex("pin_1");
      console.log("Index on pin dropped");
    }
  } catch (err) {
    console.error("Error occurred while working with MongoDB:", err);
  } finally {
    await client.close();
  }
}

checkIndexes();
